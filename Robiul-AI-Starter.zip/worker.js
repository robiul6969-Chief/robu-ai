// Robiul AI — Cloudflare Worker backend
// Add GEMINI_API_KEY as a Worker secret in Cloudflare.
// Do NOT put your API key in index.html or a public GitHub repository.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }
    if (request.method !== "POST") {
      return json({ error: "Robiul AI API is running. Send a POST request." }, 200);
    }
    if (!env.GEMINI_API_KEY) {
      return json({ error: "Server সেটআপ অসম্পূর্ণ: GEMINI_API_KEY secret যোগ করা হয়নি।" }, 500);
    }

    try {
      const body = await request.json();
      const message = String(body.message || "").trim();
      const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
      const image = body.image || null;
      const useWebSearch = Boolean(body.webSearch);

      if (!message && !image) return json({ error: "একটি প্রশ্ন লিখো অথবা ছবি আপলোড করো।" }, 400);
      if (message.length > 12000) return json({ error: "প্রশ্নটি অনেক বড়। ছোট করে পাঠাও।" }, 413);

      const contents = [];
      for (const item of history) {
        if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string") continue;
        contents.push({
          role: item.role,
          parts: [{ text: item.text.slice(0, 12000) }]
        });
      }

      const currentParts = [];
      currentParts.push({
        text: message || "এই ছবিটি দেখে বাংলায় ব্যাখ্যা করো।"
      });

      if (image && typeof image.data === "string" && typeof image.mimeType === "string") {
        const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
        if (!allowedTypes.includes(image.mimeType)) {
          return json({ error: "JPG, PNG অথবা WEBP ছবি ব্যবহার করো।" }, 400);
        }
        if (image.data.length > 5_000_000) {
          return json({ error: "ছবিটি বড়। ৩ MB-এর কম ছবি ব্যবহার করো।" }, 413);
        }
        currentParts.push({
          inline_data: {
            mime_type: image.mimeType,
            data: image.data
          }
        });
      }

      contents.push({ role: "user", parts: currentParts });

      const payload = {
        systemInstruction: {
          parts: [{
            text: "তোমার নাম Robiul AI। তুমি বন্ধুসুলভ, সহায়ক AI assistant। ব্যবহারকারী বাংলায় লিখলে সহজ বাংলায় উত্তর দাও; ইংরেজিতে লিখলে প্রয়োজনমতো ইংরেজিতে উত্তর দাও। কোড চাইলে সম্পূর্ণ, পরিষ্কার কোড ও ব্যবহারবিধি দাও। তুমি ভুল করতে পারো—অনিশ্চিত হলে তা স্পষ্ট বলবে, বানানো তথ্যকে সত্য বলে উপস্থাপন করবে না। ছবি থাকলে সেটির দৃশ্যমান বিষয়বস্তু বিশ্লেষণ করো।"
          }]
        },
        contents,
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 4096
        }
      };

      if (useWebSearch) {
        payload.tools = [{ google_search: {} }];
      }

      const apiResponse = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": env.GEMINI_API_KEY
          },
          body: JSON.stringify(payload)
        }
      );

      const result = await apiResponse.json();
      if (!apiResponse.ok) {
        const detail = result?.error?.message || "AI সার্ভিসে সমস্যা হয়েছে।";
        return json({ error: detail }, apiResponse.status === 429 ? 429 : 502);
      }

      const parts = result?.candidates?.[0]?.content?.parts || [];
      const answer = parts.map(p => p.text || "").filter(Boolean).join("\n").trim();
      const grounding = result?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const sources = grounding
        .map(g => g.web)
        .filter(w => w && w.uri)
        .map(w => ({ title: w.title || w.uri, url: w.uri }))
        .filter((item, index, arr) => arr.findIndex(x => x.url === item.url) === index)
        .slice(0, 8);

      return json({
        answer: answer || "দুঃখিত, এবার উত্তর পাওয়া যায়নি। আবার চেষ্টা করো।",
        sources
      });
    } catch (error) {
      return json({ error: "রিকোয়েস্টটি প্রসেস করা যায়নি। ইন্টারনেট বা ইনপুট পরীক্ষা করে আবার চেষ্টা করো।" }, 500);
    }
  }
};
